#!/bin/bash
# -*- mode: shell-script; indent-tabs-mode: nil; sh-basic-offset: 4; -*-
# ex: ts=8 sw=4 sts=4 et filetype=sh

[[ $1 == "add" ]] || exit 0
[[ $2 ]] || exit 1

exec depmod -a "$2"
#!/bin/bash
# -*- mode: shell-script; indent-tabs-mode: nil; sh-basic-offset: 4; -*-
# ex: ts=8 sw=4 sts=4 et filetype=sh

[[ $1 == "add" ]] || exit 0
[[ $2 ]] || exit 1

exec depmod -a "$2"
#!/bin/bash
# -*- mode: shell-script; indent-tabs-mode: nil; sh-basic-offset: 4; -*-
# ex: ts=8 sw=4 sts=4 et filetype=sh

[[ $1 == "add" ]] || exit 0
[[ $2 ]] || exit 1

exec depmod -a "$2"

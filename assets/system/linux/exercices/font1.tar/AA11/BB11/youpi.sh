On prend. Faut bien que cela s'arrete.

Bientot on decidera.

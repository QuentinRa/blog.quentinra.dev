<div class="header">
    <div>
        <span class="logo-container">Gestion clients</span>
    </div>
    <ul class="link-header-container">
        <li class="link-header-item">
            <a href="index.php">Home</a>
        </li>
        <li class="link-header-item">
            <a href="about.php">About</a>
        </li>
    </ul>
</div>

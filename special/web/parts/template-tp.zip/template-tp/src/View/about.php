Je suis la page about
<p>
    Ce site vous est fourni par <?php echo $data['founder'] ?>
</p>

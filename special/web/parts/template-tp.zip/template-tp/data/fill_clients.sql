\copy client(num_client, nom_client, prenom_client, debit_client) FROM 'fill_clients.csv' WITH DELIMITER AS ','

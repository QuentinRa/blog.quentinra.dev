package models;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.AbstractListModel;
import javax.swing.JList;
import javax.swing.ListModel;

/**
 * Special ListModel containig only unique names.
 * names list acces must be atomic in order to be thread safe (1st thread
 * to gain atomic access to the list, blocks other threads access to this list).
 * So all access to {@link #nameSet} are performed in synchronized blocks
 * {@code
 * synchronized(nameSet)
 * {
 * 	...
 * }
 * }
 * Adding or removing elements from the {@link #nameSet} also triggers
 * a fireContentsChanged on all elements of the list (which might have
 * been resorted) which allow the {@link ListModel} to notify any
 * associated widget (such as a {@link JList}).
 * @see {@link javax.swing.AbstractListModel}
 */
public class NameSetListModel extends AbstractListModel<String>
{
	/**
	 * Serial ID (because {@link AbstractListModel} is serializable)
	 */
	private static final long serialVersionUID = -4064595795097980179L;

	/**
	 * Observable unique names set (eventually sorted)
	 * @see ObservableSortedSet
	 */
	private ObservableSortedSet<String> nameSet = null;

	/**
	 * Map indicating if a specific user is connected or not
	 */
	private Map<String, Boolean> connectedMap = null;

	/**
	 * Constructor
	 */
	public NameSetListModel()
	{
		nameSet = new ObservableSortedSet<String>();
		connectedMap = new TreeMap<String, Boolean>();
	}

	/**
	 * Name set accessor
	 * @return the internal observable name set
	 */
	public ObservableSortedSet<String> getSet()
	{
		return nameSet;
	}

	/**
	 * Add a name to the name set
	 * @param userName the name to add
	 * @return true the name to add was non null, non empty, not already present
	 * in the name set and has been added to the name set
	 * @warning don't forget to trigger a
	 * {@link #fireContentsChanged(Object, int, int)} when a name has
	 * been successfully added in order for the widgets to be notified
	 * of any change
	 */
	public boolean add(String userName)
	{
		if ((userName != null) && (userName.length() > 0))
		{
			synchronized (nameSet)
			{
				if (nameSet.add(userName))
				{
					/*
					 * When we add an author to the list we expect the user
					 * to be connected
					 */
					connectedMap.put(userName, Boolean.TRUE);
					/*
					 * Notify observers of the change
					 */
					fireContentsChanged(this, 0, nameSet.size()-1);
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Check if name set contains a specific name
	 * @param userName the name to search for
	 * @return true if name set already contains this name, false otherwise
	 */
	public boolean contains(String userName)
	{
		synchronized (nameSet)
		{
			return nameSet.contains(userName);
		}
	}

	/**
	 * Check if the user provided in value is still connected
	 * @param userName the name of the user
	 * @return true if user provided by "value" exists and is connected,
	 * false otherwise
	 */
	public boolean isConnected(String userName)
	{
		if (connectedMap.containsKey(userName))
		{
			return connectedMap.get(userName).booleanValue();
		}

		return false;
	}

	/**
	 * Set specified user connected status
	 * @param userName the name of the user to set connection status
	 * @param connected the new connection status
	 * @return true if the user exist in this model and its connected
	 * status has been set
	 */
	public boolean setConnected(String userName, boolean connected)
	{
		if (connectedMap.containsKey(userName))
		{
			connectedMap.put(userName, (connected ? Boolean.TRUE : Boolean.FALSE));
			return true;
		}

		return false;
	}

	/**
	 * Remove the name at specific index from the name set
	 * @param index the index of the name to remove from name set
	 * @return true if element at index has been successfully removed, false
	 * otherwise
	 * @warning don't forget to trigger a
	 * {@link #fireContentsChanged(Object, int, int)} when a name has
	 * been successfully removed in order for the widgets to be notified
	 * of any change.
	 */
	public boolean remove(int index)
	{
		boolean result = false;
		if ((index >= 0) && (index < nameSet.size()))
		{
			int count = 0;
			synchronized (nameSet)
			{
				for (Iterator<String> it = nameSet.iterator(); it.hasNext();)
				{
					it.next();
					if (count == index)
					{
						it.remove();
						fireContentsChanged(this, 0, nameSet.size());
						result = true;
						break;
					}
					count++;
				}

				if (result)
				{
					// remove item from connectedMap as well
					count = 0;
					Set<String> keys = connectedMap.keySet();
					for (Iterator<String> it = keys.iterator(); it.hasNext(); )
					{
						String key = it.next();
						if (count == index)
						{
							it.remove(); // unnecessary
							connectedMap.remove(key);
							break;
						}
					}
				}
			}
		}

		return result;
	}

	/**
	 * Clears names et content
	 * @warning don't forget to trigger a
	 * {@link #fireContentsChanged(Object, int, int)} when the name set content
	 * changes in order for the widgets to be notified of any change.
	 */
	public void clear()
	{
		if (!nameSet.isEmpty())
		{
			nameSet.clear();
			fireContentsChanged(this, 0, nameSet.size());
		}
	}

	/**
	 * Number of elements in the name set
	 * @return the number of elements in the name set
	 * @see javax.swing.ListModel#getSize()
	 */
	@Override
	public int getSize()
	{
		return nameSet.size();
	}

	/**
	 * Accessor to ith element in the name set
	 * @param the index of deisred element
	 * @return The String corresponding to the desired element or null
	 * if there is no such element.
	 * @see javax.swing.ListModel#getElementAt(int)
	 */
	@Override
	public String getElementAt(int index)
	{
		if ((index >= 0) && (index < nameSet.size()))
		{
			int count = 0;
			String element = null;
			synchronized (nameSet)
			{
				for (Iterator<String> it = nameSet.iterator(); it.hasNext()
				     && (count <= index);)
				{
					element = it.next();
					count++;
				}
			}
			return element;
		}
		return null;
	}

	/**
	 * String representation of the name set
	 * @return a string representation of the name set
	 */
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		for (Iterator<String> it = nameSet.iterator(); it.hasNext();)
		{
			sb.append(it.next());
			if (it.hasNext())
			{
				sb.append(", ");
			}
		}
		return sb.toString();
	}
}

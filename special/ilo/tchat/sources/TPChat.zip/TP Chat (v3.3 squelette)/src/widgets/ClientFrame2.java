package widgets;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;
import java.util.logging.Logger;
import java.util.stream.Stream;

import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.TransferHandler;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.StyleConstants;

import chat.Vocabulary;
import models.AuthorListFilter;
import models.Message;
import models.Message.MessageOrder;
import models.NameSetListModel;
import models.messagesRunners.ObjectMessagesRunner;

/**
 * Chat GUI v2.0 with
 * <ul>
 * <li>server message display based on {@link Message} objects rather than just
 * text but still with a different color for each user.</li>
 * <li>A text field to send new messages to the server</li>
 * <li>A List of all users which have sent a message drawn with their respective
 * color (by using a {@link ColorTextRenderer}). Selections in this list can be
 * used to filter messages</li>
 * </ul>
 * @author davidroussel
 */
public class ClientFrame2 extends AbstractClientFrame
{
	/**
	 * Serial ID (because {@link TransferHandler} is serializable)
	 */
	private static final long serialVersionUID = -7278574480208850744L;

	/**
	 * user's name (used to initialize content in the users list)
	 */
	private String clientName;

	/**
	 * List of all received messages
	 */
	private List<Message> messages;

	/**
	 * Special ListModel containig only unique names and associated to the users
	 * list. This user list model should be provided when creating the
	 * {@link JList} in the UI
	 */
	private NameSetListModel userListModel;

	/**
	 * List selection model of the users list indicating which elements are
	 * selected in the users list represented by the {@link #userListModel}.
	 */
	private ListSelectionModel userListSelectionModel = null;

	/**
	 * Filter used to filter messages based users names selected in the
	 * {@link #userListSelectionModel} and {@link #userListModel}
	 */
	private AuthorListFilter authorFilter = null;

	/**
	 * Flag indicating the filtering status (on/off)
	 */
	private boolean filtering;

	/**
	 * The {@link JTextField} containing the messages to send to server
	 */
	private JTextField sendField;

	/**
	 * {@link JLabel} indicating the name of the server we're connected to
	 */
	private JLabel serverLabel;

	/**
	 * Reference to the current window (useful in internal classes)
	 */
	protected final AbstractClientFrame frameRef;

	/**
	 * Action to quit application
	 */
	private final Action quitAction = new QuitAction();

	/**
	 * Action to send message to server
	 */
	private final Action sendAction = new SendMessageAction();

	/**
	 * Action to clear messages in {@link AbstractClientFrameStandalone#document}
	 */
	private final Action clearMessagesAction = new ClearMessagesAction();

	/**
	 * Action to filter messages in the {@link AbstractClientFrameStandalone#document}
	 * based on {@link #userListModel}'s selected users in
	 * {@link #userListSelectionModel}.
	 */
	private final FilterMessagesAction filterAction = new FilterMessagesAction();

	/**
	 * Action to clear {@link #userListModel}'s {@link #userListSelectionModel}
	 * selection
	 */
	private final Action clearSelectionAction = new ClearListSelectionAction();

	/**
	 * Action to kick all {@link #userListModel}'s
	 * {@link #userListSelectionModel} selected users
	 */
	private final Action kickAction = new KickUserAction();

	/**
	 * Action to sort all messages by date
	 */
	private final Action sortByDateAction = new SortAction(MessageOrder.DATE);

	/**
	 * Action to sort all messages by author
	 */
	private final Action sortByUserAction = new SortAction(MessageOrder.AUTHOR);

	/**
	 * Action to sort all messages by content
	 */
	private final Action sortByContentAction = new SortAction(MessageOrder.CONTENT);

	/**
	 * Window constructor
	 * @param name user's name
	 * @param host server's name or IP address
	 * @param commonRun common run with other threads
	 * @param parentLogger parent logger
	 * @throws HeadlessException when code that is dependent on a keyboard,
	 * display, or mouse is called in an environment that does not support a
	 * keyboard, display, or mouse
	 */
	public ClientFrame2(String name,
	                              String host,
	                              Boolean commonRun,
	                              Logger parentLogger)
	    throws HeadlessException
	{
		// ------------------------------------------------------------
		// Attributes initialization
		// ------------------------------------------------------------
		super(name, host, commonRun, parentLogger);

		// ------------------------------------------------------------
		// Messages runner
		//-------------------------------------------------------------
		messagesRunner = new ObjectMessagesRunner(this, commonRun, logger);

		frameRef = this;
		clientName = name;
		userListModel = new NameSetListModel();
		userListModel.add(clientName);

		messages = new Vector<Message>();

		filtering = false;

		// -------------------------------------------------------------
		// Window builder part
		// -------------------------------------------------------------
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnConnections = new JMenu("Connections");
		menuBar.add(mnConnections);

		JMenuItem mntmQuit = new JMenuItem(quitAction);
		mnConnections.add(mntmQuit);

		JMenu mnMessages = new JMenu("Messages");
		menuBar.add(mnMessages);

		JMenuItem mntmClear = new JMenuItem(clearMessagesAction);
		mnMessages.add(mntmClear);

		JCheckBoxMenuItem chckbxmntmFilter = new JCheckBoxMenuItem(filterAction);
		mnMessages.add(chckbxmntmFilter);

		JMenu mnSort = new JMenu("Sort");
		mnMessages.add(mnSort);

		JCheckBoxMenuItem mntmDate = new JCheckBoxMenuItem(sortByDateAction);
		mnSort.add(mntmDate);

		JCheckBoxMenuItem mntmUser = new JCheckBoxMenuItem(sortByUserAction);
		mnSort.add(mntmUser);

		JCheckBoxMenuItem mntmContent = new JCheckBoxMenuItem(sortByContentAction);
		mnSort.add(mntmContent);

		JMenu mnUsers = new JMenu("Users");
		menuBar.add(mnUsers);

		JMenuItem mntmClearSelection = new JMenuItem(clearSelectionAction);
		mnUsers.add(mntmClearSelection);

		JMenuItem mntmKickSelected = new JMenuItem(kickAction);
		mnUsers.add(mntmKickSelected);

		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);
		getContentPane().add(toolBar, BorderLayout.NORTH);

		JButton quitButton = new JButton(quitAction);
		quitButton.setHideActionText(true);
		toolBar.add(quitButton);

		Component horizontalStrut = Box.createHorizontalStrut(20);
		toolBar.add(horizontalStrut);

		JButton clearSelButton = new JButton(clearSelectionAction);
		clearSelButton.setHideActionText(true);
		toolBar.add(clearSelButton);

		JButton kickButton = new JButton(kickAction);
		kickButton.setHideActionText(true);
		toolBar.add(kickButton);

		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		toolBar.add(horizontalStrut_1);

		JButton clearMessagesButton = new JButton(clearMessagesAction);
		clearMessagesButton.setHideActionText(true);
		toolBar.add(clearMessagesButton);

		JToggleButton filterToggleButton = new JToggleButton(filterAction);
		filterToggleButton.setHideActionText(true);
		toolBar.add(filterToggleButton);

		Component horizontalGlue = Box.createHorizontalGlue();
		toolBar.add(horizontalGlue);

		serverLabel = new JLabel(host);
		toolBar.add(serverLabel);

		JPanel leftPanel = new JPanel();
		leftPanel.setMaximumSize(new Dimension(150, 32767));
		leftPanel.setPreferredSize(new Dimension(150, 10));
		leftPanel.setMinimumSize(new Dimension(150, 10));
		getContentPane().add(leftPanel, BorderLayout.WEST);
		leftPanel.setLayout(new GridLayout(1, 1, 0, 0));

		JScrollPane listScrollPane = new JScrollPane();
		leftPanel.add(listScrollPane);

		JList<String> userList = new JList<String>(userListModel);
		userList.setBackground(UIManager.getColor("List.background"));
		listScrollPane.setViewportView(userList);

		JPopupMenu popupMenu = new JPopupMenu();
		addPopup(userList, popupMenu);

		JMenuItem mntmClearSelection_1 = new JMenuItem(clearSelectionAction);
		popupMenu.add(mntmClearSelection_1);

		JMenuItem mntmKickUser = new JMenuItem(kickAction);
		popupMenu.add(mntmKickUser);

		JPanel sendPanel = new JPanel();
		getContentPane().add(sendPanel, BorderLayout.SOUTH);
		sendPanel.setLayout(new BorderLayout(0, 0));

		sendField = new JTextField();
		sendField.setAction(sendAction);
		sendPanel.add(sendField);
		sendField.setColumns(10);

		JButton sendButton = new JButton(sendAction);
		sendButton.setHideActionText(true);
		sendPanel.add(sendButton, BorderLayout.EAST);

		JScrollPane messagesScrollPane = new JScrollPane();
		getContentPane().add(messagesScrollPane, BorderLayout.CENTER);

		JTextPane textPane = new JTextPane();
		textPane.setEditable(false);
		messagesScrollPane.setViewportView(textPane);

		// -------------------------------------------------------------
		// End of Window builder part
		// -------------------------------------------------------------
		/*
		 * DONE Adds a window listener to the frame so the application can
		 * quit when window is closed
		 */
		addWindowListener(new FrameWindowListener());

		/*
		 * DONE autoscroll textPane to bottom
		 * 	- Get caret from textPane
		 * 	- An set its update policy to ALWAYS_UPDATE
		 */
		DefaultCaret caret = (DefaultCaret) textPane.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		/*
		 * DONE Setup document and documentStylee
		 * 	- Get Styled Document from textPane
		 * 	- Adds a new style to the document and stor it into documentStyle
		 * 	- Get foreground color from StyleConstants into defaultColor
		 */
		document = textPane.getStyledDocument();
		documentStyle = textPane.addStyle("New Style", null);
		defaultColor = StyleConstants.getForeground(documentStyle);

		/*
		 * DONE register all widgets associated to the filterAction
		 */
		filterAction.registerButton(chckbxmntmFilter);
		filterAction.registerButton(filterToggleButton);

		/*
		 * DONE Setup List models
		 * 	- Add a new Cell Renderer to your list (a ColorTextRenderer)
		 * 	- Add userListModel to your creation of the JList
		 * 	- Get userListSelectionModel from your list
		 * 	- Add a new List Selection Listener
		 * 	(a UserListSelectionListener) to the userListSelectionModel
		 */
		userList.setCellRenderer(new ColorTextRenderer());
		userList.setSelectedIndex(0);
		userListSelectionModel = userList.getSelectionModel();
		userListSelectionModel.addListSelectionListener(new UserListSelectionListener());

		/*
		 * DONE Create a new AuthorListFilter with userListModel and
		 * userListSelectionModel
		 */
		authorFilter = new AuthorListFilter(userListModel, userListSelectionModel);
	}

	/**
	 * Adds new message as {@link Message} object
	 * @param m the message to add
	 */
	@Override
	public void addMessage(Message m)
	{
		messages.add(m);
	}

	/**
	 * Adds new message as text : Does nothing in this implementation
	 * @param m the message to add
	 */
	@Override
	public void addMessage(String s)
	{
	}

	/**
	 * Adds a new user
	 * @param user the new user to add
	 */
	@Override
	public void addUserName(String user)
	{
		userListModel.add(user);
	}

	/**
	 * Cleanup: clear {@link #messages}, and calls super cleanup
	 * @see AbstractClientFrameStandalone#cleanup()
	 */
	@Override
	public void cleanup()
	{
		messages.clear();
		super.cleanup();
	}

	/**
	 * Adds a new message at the end of {@link AbstractClientFrameStandalone#document}.
	 * The date part of the message "[yyyy/MM/dd HH:mm:ss]" should be displayed
	 * with default color whereas the "user > message" part should be displayed
	 * with user's specific color ({@link #getColorFromName(String)})
	 * @param message The message to display
	 * le message à afficher dans le
	 * {@link AbstractClientFrameStandalone#document} en modifiant au besoin le
	 * {@link AbstractClientFrameStandalone#documentStyle}
	 * @throws BadLocationException if the position to insert text is invalid
	 */
	protected void appendMessage(Message message)// throws BadLocationException
	{
		try
		{
			/*
			 * DONE Adds message date to the end of the document with default
			 * style
			 */
			document.insertString(document.getLength(),
			                      "[" + message.getFormattedDate() + "] ",
			                      documentStyle);

			/*
			 * DONE If message has no author (server's message) adds the
			 * message content with default style,
			 * otherwise
			 * Adds "user > content" message part with user's color
			 * obtained from AbstractClientFrame#getColorFromName using
			 * then re-set the default style in document Style
			 */
			if (!message.hasAuthor())
			{
				document.insertString(document.getLength(),
				                      message.getContent() +
				                      Vocabulary.newLine,
				                      documentStyle);
			}
			else
			{
				String author = message.getAuthor();
				StringBuffer sb = new StringBuffer();
				sb.append(author);
				sb.append(" > ");
				sb.append(message.getContent());
				sb.append(Vocabulary.newLine);

				// Change text color in document style
				StyleConstants.setForeground(documentStyle,
				                             getColorFromName(author));

				document.insertString(document.getLength(),
				                      sb.toString(),
				                      documentStyle);

				// return to default style
				StyleConstants.setForeground(documentStyle, defaultColor);
			}
		}
		catch (BadLocationException ble)
		{
			logger.warning("ClientFrame2::appendMessage(...); Bad Location : "
			    + ble.getLocalizedMessage());
		}
	}

	/**
	 * Update all messages in document according to {@link #authorFilter}'s
	 * status and ordering set into {@link Message} class
	 */
	@Override
	public void updateMessages() // throws BadLocationException
	{
		/*
		 * DONE Clear document
		 */
		try
		{
			// Clears document
			document.remove(0, document.getLength());
		}
		catch (BadLocationException ex)
		{
			logger.warning("ClientFrame::updateMessages: bad location"
			    + ex.getLocalizedMessage());
		}

		/*
		 * DONE Then creates a stream from messages
		 */
		Stream<Message> stream = messages.stream();

		/*
		 * DONE Message has any orders then sort the stream
		 */
		if (Message.orderSize() > 0)
		{
			// If there is an ordering set into Message sort the stream
			stream = stream.sorted();
		}

		/*
		 * DONE if filtering is on then filter the stream with authorFilter
		 */
		if (filtering)
		{
			// filter sorted stream according to #authorFilter
			stream = stream.filter(authorFilter);
		}

		/*
		 * DONE finally append all remaining messages on the stream with
		 * appenMessage(...)
		 */
		stream.forEach((Message m) -> appendMessage(m));
	}

	/**
	 * Adds a Popup Menu to a component
	 * @param component the component to add popup to
	 * @param popup The popup menu to add
	 */
	private static void addPopup(Component component, final JPopupMenu popup)
	{
		component.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mousePressed(MouseEvent e)
			{
				if (e.isPopupTrigger())
				{
					showMenu(e);
				}
			}

			@Override
			public void mouseReleased(MouseEvent e)
			{
				if (e.isPopupTrigger())
				{
					showMenu(e);
				}
			}

			private void showMenu(MouseEvent e)
			{
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}

	// ----------------------------------------------------------------
	// App related actions
	// ----------------------------------------------------------------
	/**
	 * Action to logout from server an quit application
	 */
	private class QuitAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = 1230763930323271538L;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut
		 */
		public QuitAction()
		{
			putValue(LARGE_ICON_KEY, new ImageIcon(ClientFrame2.class
				.getResource("/icons/disconnected-32.png")));
			putValue(SMALL_ICON, new ImageIcon(ClientFrame2.class
				.getResource("/icons/disconnected-16.png")));
			putValue(NAME, "Quit");
			putValue(SHORT_DESCRIPTION,
				"Close connection from server and quit");
		}

		/**
		 * Action performing: Clears {@link ClientFrameStandalone1#serverLabel} and send
		 * {@link Vocabulary#byeCmd} to server which should terminate this frame
		 * with the {@link AbstractClientFrameStandalone#commonRun} changing to false
		 * @param e the event that triggered this action [not used]
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			logger.info("QuitAction: sending bye ... ");
			sendMessage(Vocabulary.byeCmd);

			serverLabel.setText("");
			frameRef.validate();

			try
			{
				Thread.sleep(1000); // don't ask why
			}
			catch (InterruptedException e1)
			{
				return;
			}
		}
	}

	// ----------------------------------------------------------------
	// Message related actions
	// ----------------------------------------------------------------
	/**
	 * Action to clear {@link AbstractClientFrameStandalone#document} content
	 */
	private class ClearMessagesAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -2770675891954134959L;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut
		 */
		public ClearMessagesAction()
		{
			putValue(LARGE_ICON_KEY, new ImageIcon(
				ClientFrame2.class.getResource("/icons/erase2-32.png")));
			putValue(SMALL_ICON, new ImageIcon(
				ClientFrame2.class.getResource("/icons/erase2-16.png")));
			putValue(NAME, "Clear Messages");
			putValue(SHORT_DESCRIPTION, "Clears messages in document");
		}

		/**
		 * Action performing: clears {@link AbstractClientFrameStandalone#document}
		 * content
		 * @param e the event that triggered this action [not used]
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			logger.info("Clear document");
			/*
			 * Clears document content
			 */
			try
			{
				document.remove(0, document.getLength());
			}
			catch (BadLocationException ex)
			{
				logger.warning("ClientFrame: clear doc: bad location");
				logger.warning(ex.getLocalizedMessage());
			}

			/*
			 * Clears user's list
			 */
			userListModel.clear();
			userListModel.add(clientName);

			/*
			 * Clears recorded messages
			 */
			messages.clear();
		}
	}

	/**
	 * Action to send message content to server
	 */
	private class SendMessageAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -459192941860640107L;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut
		 */
		public SendMessageAction()
		{
			putValue(SMALL_ICON, new ImageIcon(
				ClientFrame2.class.getResource("/icons/sent-16.png")));
			putValue(LARGE_ICON_KEY, new ImageIcon(
				ClientFrame2.class.getResource("/icons/sent-32.png")));
			putValue(NAME, "Send Message");
			putValue(SHORT_DESCRIPTION, "Send Message to server");
		}

		/**
		 * Action performing: retreive {@link ClientFrame2#sendTextField}
		 * content
		 * if non empty and send it to server
		 * @param e the event that triggered this action [not used]
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			String content = sendField.getText();

			logger.info("Sending message = " + content);

			// Send message if non null or empty
			if (content != null)
			{
				if (content.length() > 0)
				{
					sendMessage(content);

					// Clears text field
					sendField.setText("");
				}
			}
		}
	}

	/**
	 * Action to filter messages according to selected users in the user's list
	 */
	private class FilterMessagesAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -4990621521308404832L;

		/**
		 * Collection of widgets attached to this action.
		 * We need to keep track of various widgets triggering this action since
		 * this action is a toggle, all associated widgets should be toggled at
		 * the same time whatever widget triggered this action first
		 */
		private Collection<AbstractButton> buttons;

		/**
		 * Constructor.
		 * Initialize {@link #buttons}, Sets name, description, icons and
		 * also action's shortcut
		 */
		public FilterMessagesAction()
		{
			buttons = new ArrayList<AbstractButton>();
			putValue(SMALL_ICON, new ImageIcon(ClientFrame2.class
				.getResource("/icons/filled_filter-16.png")));
			putValue(LARGE_ICON_KEY, new ImageIcon(ClientFrame2.class
				.getResource("/icons/filled_filter-32.png")));
			putValue(NAME, "Filter Messages");
			putValue(SHORT_DESCRIPTION,
				"Filter Messages according to selected users");
		}

		/**
		 * Add a new {@link AbstractButton} to the list of widgets triggering
		 * this action
		 * @param button the button to add
		 * @return true if the button was non null and not already present in
		 * the {@link #buttons} list. False otherwise.
		 */
		public boolean registerButton(AbstractButton button)
		{
			if (button != null)
			{
				if (!buttons.contains(button))
				{
					return buttons.add(button);
				}
			}
			return false;
		}

		/**
		 * Remove a button from {@link #buttons} list.
		 * @param button the button to remove
		 * @return true if the button was non null, belonged to the
		 * {@link #buttons} list and was successfully removed from
		 * {@link #buttons}
		 */
		public boolean unregisterButton(AbstractButton button)
		{
			if (button != null)
			{
				if (buttons.contains(button))
				{
					return buttons.remove(button);
				}
			}
			return false;
		}

		/**
		 * Cleanup before destruction
		 */
		@Override
		protected void finalize()
		{
			for (AbstractButton b: buttons)
			{
				unregisterButton(b);
			}

			buttons.clear();
		}

		/**
		 * Action performing: Toggle filtering on/off then
		 * {@link ClientFrame2#updateMessages()}
		 * @param e the event that triggered this action. Used to determine
		 * button source
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			/*
			 * DONE Get source, then source state to see if it is selected
			 */
			AbstractButton button = (AbstractButton)e.getSource();

			boolean newFiltering = button.isSelected();
			logger.info("Filtering is " + (newFiltering ? "On" : "Off"));

			/*
			 * DONE Set Filtering on authorFilter and update messages
			 */
			authorFilter.setFiltering(newFiltering);
			if (newFiltering != filtering)
			{
				filtering = newFiltering;
				updateMessages();
			}

			/*
			 * DONE Update all buttons associated to this action
			 */
			for (AbstractButton b : buttons)
			{
				if (b != button)
				{
					b.setSelected(newFiltering);
				}
			}
		}
	}

	// ----------------------------------------------------------------
	// User list related actions
	// ----------------------------------------------------------------
	/**
	 * Action to clear user's selection in users list
	 */
	private class ClearListSelectionAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = 6368840308418452167L;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut
		 */
		public ClearListSelectionAction()
		{
			putValue(SMALL_ICON, new ImageIcon(ClientFrame2.class
				.getResource("/icons/delete_database-16.png")));
			putValue(LARGE_ICON_KEY, new ImageIcon(ClientFrame2.class
				.getResource("/icons/delete_database-32.png")));
			putValue(NAME, "Clear selected");
			putValue(SHORT_DESCRIPTION, "Clear selected items");
		}

		/**
		 * Action performing: Clears the
		 * {@link ClientFrame2#userListSelectionModel} and also the
		 * {@link ClientFrame2#authorFilter}
		 * @param e the event that triggered this action [not used]
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			/*
			 * DONE Clears userListSelectionModel, authorFilter
			 * and evt update messages
			 */
			userListSelectionModel.clearSelection();
			authorFilter.clear();
			if (filtering)
			{
				updateMessages();
			}
		}
	}

	/**
	 * Action for kicking (or at least try to kick) all selected users from chat
	 * server
	 */
	private class KickUserAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -8029776262924225534L;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut
		 */
		public KickUserAction()
		{
			putValue(SMALL_ICON,
			         new ImageIcon(ClientFrame2.class
			             .getResource("/icons/remove_user-16.png")));
			putValue(LARGE_ICON_KEY,
			         new ImageIcon(ClientFrame2.class
			             .getResource("/icons/remove_user-32.png")));
			putValue(NAME, "Kick Selected Users");
			putValue(SHORT_DESCRIPTION, "Kick users selected in the user list");
		}

		/**
		 * Action performing: Sends a {@link Vocabulary#kickCmd} for each of the
		 * users selected in the users list
		 * @param e the event that triggered this action [not used]
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			/*
			 * DONE Get all selected used from userListSelectionModel
			 * and userListModel and send a kick request to the server
			 * for each of them.
			 * e.g. : "kick MyNemesis"
			 * N.B. Kick is part of Vocabulary : Vocabulary.kickCmd
			 */
			int minIndex = userListSelectionModel.getMinSelectionIndex();
			int maxIndex = userListSelectionModel.getMaxSelectionIndex();
			logger.info("Scanning users from index " + String.valueOf(minIndex)
			    + " to " + String.valueOf(maxIndex));
			for (int i = minIndex; i <= maxIndex; i++)
			{
				if (userListSelectionModel.isSelectedIndex(i))
				{
					String userName = userListModel.getElementAt(i);
					// Then kick those users
					logger.info("Kicking " + userName);
					sendMessage(Vocabulary.kickCmd + " " + userName);
				}
			}
		}
	}

	/**
	 * Action to sort messages according to specific ordering set into
	 * {@link Message}
	 */
	private class SortAction extends AbstractAction
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -8690818752859664484L;

		/**
		 * Message ordering to set in this action:
		 * <ul>
		 * <li>{@link Message.MessageOrder#AUTHOR} to sort messages by
		 * author</li>
		 * <li>{@link Message.MessageOrder#DATE} to sort messages by date</li>
		 * <li>{@link Message.MessageOrder#CONTENT} to serot messages by
		 * content</li>
		 * </ul>
		 */
		private MessageOrder order;

		/**
		 * Constructor.
		 * Sets name, description, icons and also action's shortcut according to
		 * the desired ordering
		 * @param order the order to set for sorting messages
		 */
		public SortAction(MessageOrder order)
		{
			this.order = order;
			switch (order)
			{
				case DATE:
					putValue(LARGE_ICON_KEY,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/clock-32.png")));
					putValue(SMALL_ICON,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/clock-16.png")));
					break;
				case AUTHOR:
					putValue(LARGE_ICON_KEY,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/gender_neutral_user-32.png")));
					putValue(SMALL_ICON,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/gender_neutral_user-16.png")));
					break;
				case CONTENT:
					putValue(LARGE_ICON_KEY,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/select_all-32.png")));
					putValue(SMALL_ICON,
					         new ImageIcon(ClientFrame2.class.getResource("/icons/select_all-16.png")));
					break;
				default:
					break;
			}
			putValue(NAME, order.toString());
			putValue(SHORT_DESCRIPTION, "Sort messages by " + order.toString());
		}

		/**
		 * Action performing: Set or unset this {@link #order} for sorting
		 * messages and update messages
		 * @param e the event that triggered this action. Used to determine
		 * if the widget triggering this action is selected or unseleced in
		 * order to set or unset sorting by adding or removing order into
		 * {@link Message} class.
		 */
		@Override
		public void actionPerformed(ActionEvent e)
		{
			/*
			 * DONE Get event source an cast it to get the selected
			 * state, then if selected add the corresponding order
			 * to Message with addOrder otherwise remove the
			 * corresponding order from Message with removeOrder
			 * And finally update messages
			 */
			AbstractButton button = (AbstractButton) e.getSource();
			boolean selected = button.getModel().isSelected();

			if (selected)
			{
				Message.addOrder(order);
				logger.info("Adding message order " + order.toString() + " : "
					+ Message.toStringOrder());
			}
			else
			{
				Message.removeOrder(order);
				logger.info("Removing message order " + order.toString() + " : "
					+ Message.toStringOrder());
			}

			updateMessages();
		}
	}

	/**
	 * Listener to handle selection changes in user's list.
	 * Updates the {@link ClientFrame2#authorFilter} according to currently
	 * selected users in the users list
	 */
	private class UserListSelectionListener implements ListSelectionListener
	{
		/**
		 * Method called when List selection changes
		 * @param ListSelectionEvent e the event that triggered this action
		 */
		@Override
		public void valueChanged(ListSelectionEvent e)
		{
			/*
			 * DONE
			 * Get first and last index of the ListSelectionEvent
			 * Get the adjusting status of the event
			 * Get the ListSelectionModel (lsm) as the source of the event
			 * Then if the event is NOT adjusting then
			 * 	Clears authorFilter
			 * 	And add each selected user of the userListModel in the
			 * lsm to the authorFilter
			 * And finally, if filtering is on updateMessages
			 *
			 * Side Note : If the list selection model is empty
			 * kickAction and clearSelectionAction should be disabled
			 * and enabled otherwise
			 */
			int firstIndex = e.getFirstIndex();
			int lastIndex = e.getLastIndex();
			logger.info("UserListSelectionListener::valueChanged : First index = "
			        + String.valueOf(firstIndex) + ", last index = "
			        + String.valueOf(lastIndex));
			boolean isAdjusting = e.getValueIsAdjusting();
			ListSelectionModel lsm = (ListSelectionModel) e.getSource();

			/*
			 * isAdjusting remains true while events like drag n drop are
			 * still processed and becomes false afterwards.
			 */
			if (!isAdjusting)
			{
				if (lsm.isSelectionEmpty())
				{
					kickAction.setEnabled(false);
					clearSelectionAction.setEnabled(false);
				}
				else
				{
					kickAction.setEnabled(true);
					clearSelectionAction.setEnabled(true);

					// Find out which indexes are selected.
					int minIndex = lsm.getMinSelectionIndex(); // same as e.getFirstIndex();
					int maxIndex = lsm.getMaxSelectionIndex(); // same as e.getLastIndex();
					logger.info("Min Model index = " + String.valueOf(minIndex)
					    + ", max model index = " + String.valueOf(maxIndex));

					authorFilter.clear();
					for (int i = minIndex; i <= maxIndex; i++)
					{
						String userName = userListModel.getElementAt(i);
						if (lsm.isSelectedIndex(i))
						{
							authorFilter.add(userName);
						}
					}

					if (filtering)
					{
						updateMessages();
					}
				}
			}
		}
	}

	/**
	 * Color Text renderer for drawing list's elements in colored text
	 * @author davidroussel
	 */
	private class ColorTextRenderer extends JLabel
		implements ListCellRenderer<String>
	{
		/**
		 * Serial ID because enclosing class is serializable ?
		 */
		private static final long serialVersionUID = -3133105073504656769L;

		/**
		 * Text color
		 */
		private Color color = null;

		/**
		 * Customized rendering for a ListCell with a color obtained from
		 * the hashCode of the string to display
		 * @see
		 * javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing
		 * .JList, java.lang.Object, int, boolean, boolean)
		 */
		@Override
		public Component getListCellRendererComponent(
			JList<? extends String> list, String value, int index,
			boolean isSelected, boolean cellHasFocus)
		{
			color = list.getForeground();
			if (value != null)
			{
				if (value.length() > 0)
				{
					color = frameRef.getColorFromName(value);
				}
			}
			setText(value);
			if (isSelected)
			{
				setBackground(color);
				setForeground(list.getSelectionForeground());
			}
			else
			{
				setBackground(list.getBackground());
				setForeground(color);
			}
			setEnabled(list.isEnabled());
			setFont(list.getFont());
			setOpaque(true);
			return this;
		}
	}


	/**
	 * Class redirecting the window closing event to the {@link QuitAction}
	 */
	protected class FrameWindowListener extends WindowAdapter
	{
		/**
		 * Method trigerred when window is closing
		 * @param e The Window event
		 */
		@Override
		public void windowClosing(WindowEvent e)
		{
			logger.info("FrameWindowListener::windowClosing: sending bye ... ");
			/*
			 * Calls the #quitAction if there is any
			 */
			if (quitAction != null)
			{
				quitAction.actionPerformed(null);
			}
		}
	}
}

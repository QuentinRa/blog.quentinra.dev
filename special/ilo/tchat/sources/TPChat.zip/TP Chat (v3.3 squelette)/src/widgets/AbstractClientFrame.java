package widgets;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.TransferHandler;
import javax.swing.WindowConstants;
import javax.swing.text.Style;
import javax.swing.text.StyledDocument;

import logger.LoggerFactory;
import models.Message;
import models.MessagesHandler;
import models.messagesRunners.AbstractMessagesRunner;

/**
 * Abstract frame containing all common elements to all GUI Chat Clients.
 * <ul>
 * <li>{@link #commonRun} to ensure common run/stop of multiple threads</li>
 * <li>{@link #inPipe} input stream to read messages from server (text or object
 * messages) and displya messages in the client.</li>
 * <li>{@link #outPipe} output stream to write messages to the server
 * (text)</li>
 * <li>{@link #outPW} output print writer to write user messages to the
 * {@link #outPipe} to the server</li>
 * <li>{@link #logger} for logging</li>
 * <li>{@link #document} The document where to write (possibly in rich text)
 * messages from server</li>
 * <li>{@link #documentStyle} to locally modify the document style in order to
 * display messages with a specific color for instance</li>
 * <li>{@link #defaultColor} to use in the {@link #documentStyle} of the
 * {@link #document}</li>
 * <li>{@link #colorMap} map associating a word with a color in order to
 * associate a unique color to each users logged on the server whe displaying
 * messages</li>
 * </ul>
 * @author davidroussel
 */
public abstract class AbstractClientFrame extends JFrame implements MessagesHandler
{
	/**
	 * Serial ID (because {@link TransferHandler} is serializable)
	 */
	private static final long serialVersionUID = 7475861952441319100L;

	/**
	 * Common run when mutiple threads are used for listening to server's
	 * messages
	 */
	protected Boolean commonRun;

	/**
	 * Helper runnable to handle messages
	 */
	protected AbstractMessagesRunner messagesRunner;

	/**
	 * Logger to show debug message or only log them in a file
	 */
	protected Logger logger;

	/**
	 * The underlying document of a {@link JTextPane} in wich messages should be
	 * displayed
	 */
	protected StyledDocument document;

	/**
	 * The sytle applied to {@link #document}
	 */
	protected Style documentStyle;

	/**
	 * Default text color in {@link #documentStyle}
	 */
	protected Color defaultColor;

	/**
	 * [protected] constructor (used in subclasses)
	 * @param name user name
	 * @param host chat server's names or IP address
	 * @param commonRun common run status with other threads in the client
	 * @param parentLogger parent logger
	 * @throws HeadlessException when code that is dependent on a keyboard,
	 * display, or mouse is called in an environment that does not support a
	 * keyboard, display, or mouse
	 */
	protected AbstractClientFrame(String name,
	                              String host,
	                              Boolean commonRun,
	                              Logger parentLogger)
		throws HeadlessException
	{
		// --------------------------------------------------------------------
		// Logger
		//---------------------------------------------------------------------
		logger = LoggerFactory.getParentLogger(getClass(),
		                                       parentLogger,
		                                       (parentLogger == null ?
		                                    	Level.INFO :
		                                    	parentLogger.getLevel()));

		// --------------------------------------------------------------------
		// Common run with other threads
		//---------------------------------------------------------------------
		if (commonRun != null)
		{
			this.commonRun = commonRun;
		}
		else
		{
			this.commonRun = Boolean.TRUE;
		}

		// --------------------------------------------------------------------
		// Messages runner
		//---------------------------------------------------------------------
		messagesRunner = null; // to be instanciated in subclasses

		// --------------------------------------------------------------------
		// Window setup
		//---------------------------------------------------------------------
		if (name != null)
		{
			setTitle(name);
		}

		setPreferredSize(new Dimension(400, 200));
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		document = null;
		documentStyle = null;
		defaultColor = Color.BLACK;
	}

	/**
	 * Send message into {@link #outPipe} (iff non null) using the
	 * {@link #outPW}
	 * @param the message to send
	 */
	protected void sendMessage(String message)
	{
		messagesRunner.sendMessage(message);
	}

	/**
	 * Compute Color from name: retrieve color from {@link #colorMap} and if
	 * this name is not already in the map add a new <name, color> to the map
	 * before retrieving
	 * @param name the name to generate color from
	 * @return a {@link Color} associated to the name or null if name is null or
	 * empty
	 * @warning Ensure similar names don't get similar colors
	 */
	protected Color getColorFromName(String name)
	{
		return messagesRunner.getColorFromName(name);
	}

	/**
	 * Cleanup: close window and streams
	 */
	public void cleanup()
	{
		logger.info("ClientFrame::cleanup: closing window ... ");
		dispose();

		synchronized (commonRun)
		{
			commonRun = false;
		}

		messagesRunner.cleanup();
	}


	/**
	 * {@link #inPipe} accessor to connect to a {@link PipedOutputStream}
	 * @return The {@link #inPipe}
	 */
	public PipedInputStream getInPipe()
	{
		return messagesRunner.getInPipe();
	}

	/**
	 * {@link #outPipe} accessor to connecto to a {@link PipedInputStream}
	 * @return The {@link #outPipe}
	 */
	public PipedOutputStream getOutPipe()
	{
		return messagesRunner.getOutPipe();
	}

	/**
	 * Adds new message
	 * @param m the message to add
	 */
	@Override
	public abstract void addMessage(Message m);

	/**
	 * Adds a new user
	 * @param user the new user to add
	 */
	@Override
	public abstract void addUserName(String user);

	/**
	 * Update all messages according to internal filtering policies
	 */
	@Override
	public abstract void updateMessages();


	/**
	 * Get internal runner (so it can be threaded)
	 * @return the internal runner
	 */
	public Runnable getMessagesRunner()
	{
		return messagesRunner;
	}
}

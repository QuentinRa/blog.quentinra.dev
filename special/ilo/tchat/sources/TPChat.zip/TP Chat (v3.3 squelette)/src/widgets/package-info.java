/**
 * PAckage containing all clients frames
 */
package widgets;

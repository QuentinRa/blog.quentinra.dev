* Nom :
* Prénom :
* Groupe :

# Réponses aux question de la partie Diagramme de classes :

* _Question_ : A quoi sert la classe AbstractRunChat ?
* _Réponse_ :

* _Question_ : Expliquez la relation ChatServer / InputOutputClient concrétisée par l’attribut « clients ».
* _Réponse_ :

* _Question_ : Expliquez la relation ClientHandler / InputClient concrétisée par l’attribut « mainClient ».
* _Réponse_ :

* _Question_ : Expliquez la relation ClientHandler / InputOutputClient concrétisée par l’attribut « allClients ».
* _Réponse_ :

* _Question_ : Combien de threads tournent sur un serveur dans le scénario présenté par la Figure 1 (page 1) ? Détaillez votre réponse en précisant qui lance qui.
* _Réponse_ :

* _Question_ : Combien de threads tournent dans le Client 1 du scénario présenté par la Figure 1 (page 1) ? Détaillez votre réponse en précisant qui lance qui.
* _Réponse_ :

* _Question_ : A quoi sert le threads[i].join() à la fin du run de ChatClient ?
* _Réponse_ :

* _Question_ : Que représente la classe ChatClient dans le cadre d’une architecture MVC ?
* _Réponse_ :


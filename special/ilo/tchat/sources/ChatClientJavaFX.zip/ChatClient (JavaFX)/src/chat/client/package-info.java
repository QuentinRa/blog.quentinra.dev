package chat.client;

/**
 * Sub package containing all client specific classes
 */

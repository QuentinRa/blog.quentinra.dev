/**
 * Custom {@link javafx.scene.control.ListCell}s for
 * 	- {@link application.Controller#userListView}
 * 	- {@link application.Controller#MessageListView}
 */
package application.listcells;

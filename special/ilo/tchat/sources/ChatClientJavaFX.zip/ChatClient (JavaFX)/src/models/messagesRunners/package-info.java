/**
 * Package containing all messages runners :
 * {@link java.lang.Runnable}s receiving messages from server and hanling them
 * to actual GUI clients eihter as Text messages or {@link models.Message}s objects
 */
package models.messagesRunners;

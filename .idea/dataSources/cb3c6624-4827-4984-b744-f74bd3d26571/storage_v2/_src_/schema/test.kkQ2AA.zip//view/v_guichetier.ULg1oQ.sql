create definer = root@localhost view v_guichetier as
select `test`.`guichetier`.`id_guichetier` AS `id_guichetier`,
       `test`.`personne`.`nom`             AS `nom`,
       `test`.`personne`.`prenom`          AS `prenom`
from (`test`.`personne`
         join `test`.`guichetier` on (`test`.`personne`.`id_personne` = `test`.`guichetier`.`id_guichetier`));


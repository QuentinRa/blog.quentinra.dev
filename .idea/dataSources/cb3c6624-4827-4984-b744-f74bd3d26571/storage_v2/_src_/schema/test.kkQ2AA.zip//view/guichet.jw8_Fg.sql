create view guichet as
select `sp`.`n_spectacle`                                                                              AS `n_spectacle`,
       `r`.`n_salle`                                                                                   AS `n_salle`,
       `r`.`r_date`                                                                                    AS `b_date`,
       `sp`.`nom`                                                                                      AS `nom`,
       `sp`.`s_type`                                                                                   AS `s_type`,
       `r`.`prix`                                                                                      AS `prix`,
       `s`.`nb_places` - (select count(0)
                          from `test`.`billet`
                          where `test`.`billet`.`n_spectacle` = `sp`.`n_spectacle`)                    AS `nb_places_libres`
from ((`test`.`spectacle` `sp` join `test`.`representation` `r` on (`sp`.`n_spectacle` = `r`.`n_spectacle`))
         join `test`.`salle` `s` on (`r`.`n_salle` = `s`.`n_salle`));


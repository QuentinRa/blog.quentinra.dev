create view representation_avec_places as
select `guichet`.`n_spectacle`      AS `n_spectacle`,
       `guichet`.`n_salle`          AS `n_salle`,
       `guichet`.`b_date`           AS `b_date`,
       `guichet`.`nom`              AS `nom`,
       `guichet`.`s_type`           AS `s_type`,
       `guichet`.`prix`             AS `prix`,
       `guichet`.`nb_places_libres` AS `nb_places_libres`
from `test`.`guichet`
where `guichet`.`nb_places_libres` > 0;

